__version__ = "d.0"

#add package level functions and dependencies here